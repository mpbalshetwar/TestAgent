﻿using System.Collections.Generic;

namespace EntitiesCore.Bots
{
    public class AIRequest
    {
        private string _intentName;
        private List<KeyValuePair<string, string>> _slots;
        private string _requestId;
        private string _type;
        private string _accessToken;
        private string _sessionId;
        private string _userId;
        private string _confirmationStatus;
        private string _version;
        private string _deviceId;
        private string _apiAccessToken;
        private string _ApiEndpoint;

        //constructor for AlexaRequestPayload attribute Value assgin to the AIRequest
        //public AIRequest(AlexaRequestPayload alexaRequestInput)
        //{
        //    IntentName = (alexaRequestInput.Request.Intent == null) ? "" : alexaRequestInput.Request.Intent.Name;
        //    Slots = alexaRequestInput.Request.Intent.GetSlots();
        //    RequestId = alexaRequestInput.Request.RequestId;
        //    SessionId = alexaRequestInput.Session.SessionId;
        //    UserId = alexaRequestInput.Session.User.UserId;
        //    Type = alexaRequestInput.Request.Type;
        //    DeviceId = alexaRequestInput.Context.System.Device.DeviceID;
        //    Version = alexaRequestInput.Version;
        //    ApiAccessToken = alexaRequestInput.Context.System.ApiAccessToken;
        //    ApiEndpoint = alexaRequestInput.Context.System.ApiEndpoint;
        //    ConfirmationStatus = alexaRequestInput.Request.Intent.ConfirmationStatus;
        //}

        //constructor for APIAIRequest attribute Value assgin to the AIRequest
        public AIRequest(DilogflowRequest alexaRequestInput)
        {
            IntentName = (alexaRequestInput.queryResult.intent.displayName == null) ? "" : alexaRequestInput.queryResult.intent.displayName;

            //this loop for get the parameters form request output context
            for (int i = 0; i < alexaRequestInput.queryResult.outputContexts.Count; i++)
            {
                if (alexaRequestInput.queryResult.outputContexts[i].name.ToString().Contains("cancelfundstransfer_dialog_context"))
                    Slots = alexaRequestInput.queryResult.outputContexts[i].parameters.GetSlots();

                else if (alexaRequestInput.queryResult.outputContexts[i].name.ToString().Contains("schedulefundstransfer_dialog_context"))
                    Slots = alexaRequestInput.queryResult.outputContexts[i].parameters.GetSlots();

                else if (alexaRequestInput.queryResult.outputContexts[i].name.ToString().Contains("schedulerecurringfundstransfer_dialog_context"))
                    Slots = alexaRequestInput.queryResult.outputContexts[i].parameters.GetSlots();

                else if (alexaRequestInput.queryResult.outputContexts[i].name.ToString().Contains("ccrecommend_dialog_context"))
                    Slots = alexaRequestInput.queryResult.outputContexts[i].parameters.GetSlots();

                else if (alexaRequestInput.queryResult.outputContexts[i].name.ToString().Contains("airline"))
                    Slots = alexaRequestInput.queryResult.outputContexts[i].parameters.GetSlots();

                else if (alexaRequestInput.queryResult.outputContexts[i].name.ToString().Contains("confirmotpsft"))
                    Slots = alexaRequestInput.queryResult.outputContexts[i].parameters.GetSlots();

                else if (alexaRequestInput.queryResult.outputContexts[i].name.ToString().Contains("confirmotpsrft"))
                    Slots = alexaRequestInput.queryResult.outputContexts[i].parameters.GetSlots();

                else if (alexaRequestInput.queryResult.outputContexts[i].name.ToString().Contains("confirmotp"))
                    Slots = alexaRequestInput.queryResult.outputContexts[i].parameters.GetSlots();

                else
                    Slots = alexaRequestInput.queryResult.parameters.GetSlots();
            }

            if (alexaRequestInput.queryResult.outputContexts.Count == 0)
            {
                Slots = alexaRequestInput.queryResult.parameters.GetSlots();
            }
            RequestId = alexaRequestInput.responseId;
            SessionId = alexaRequestInput.session;

            UserId = "12354";
            Type = "Dialogflow";
            DeviceId = "";
            Version = "1.0";
            ConfirmationStatus = "none";//alexaRequestInput.Request.Intent.ConfirmationStatus;
        }

        //constructor for APIAIRequest attribute Value assgin to the AIRequest
        //public AIRequest(WebhookRequest alexaRequestInput, List<KeyValuePair<string, string>> Liststr)
        //{
        //    IntentName = (alexaRequestInput.QueryResult.Intent.DisplayName == null) ? "" : alexaRequestInput.QueryResult.Intent.DisplayName;
        //    Slots = Liststr;
        //    RequestId = alexaRequestInput.ResponseId;
        //    SessionId = alexaRequestInput.Session;
        //    UserId = "12354";
        //    Type = "IntentRequest";
        //    DeviceId = "";
        //    Version = "1.0";
        //    ConfirmationStatus = "none";//alexaRequestInput.Request.Intent.ConfirmationStatus;
        //}

        public string IntentName
        {
            get { return _intentName; }
            set { _intentName = value; }
        }

        public List<KeyValuePair<string, string>> Slots
        {
            get { return _slots; }
            set { _slots = value; }
        }

        public string RequestId
        {
            get { return _requestId; }
            set { _requestId = value; }
        }
        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }
        public string AccessToken
        {
            get { return _accessToken; }
            set { _accessToken = value; }
        }
        public string SessionId
        {
            get { return _sessionId; }
            set { _sessionId = value; }
        }
        public string UserId
        {
            get { return _userId; }
            set { _userId = value; }
        }
        public string ConfirmationStatus
        {
            get { return _confirmationStatus; }
            set { _confirmationStatus = value; }
        }
        public string Version
        {
            get { return _version; }
            set { _version = value; }
        }
        public string DeviceId
        {
            get { return _deviceId; }
            set { _deviceId = value; }
        }


        public string ApiAccessToken { get => _apiAccessToken; set => _apiAccessToken = value; }
        public string ApiEndpoint { get => _ApiEndpoint; set => _ApiEndpoint = value; }
    }
}