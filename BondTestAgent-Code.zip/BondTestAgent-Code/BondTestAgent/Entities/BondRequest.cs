﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace EntitiesCore.Bots
{
    [JsonObject]
    public class BondRequest
    {
        [JsonProperty("responseId")]
        public string responseId { get; set; }
        [JsonProperty("queryResult")]
        public Queryresult queryResult { get; set; }
        [JsonProperty("originalDetectIntentRequest")]
        public Originaldetectintentrequest originalDetectIntentRequest { get; set; }
        [JsonProperty("session")]
        public string session { get; set; }

        [JsonObject("Queryresult")]
        public class Queryresult
        {

            [JsonProperty("queryText")]
            public string queryText { get; set; }
            [JsonProperty("parameters")]
            public dynamic Parameters { get; set; }
            [JsonProperty("allRequiredParamsPresent")]
            public bool allRequiredParamsPresent { get; set; }
            [JsonProperty("fulfillmentText")]
            public string fulfillmentText { get; set; }
            [JsonProperty("fulfillmentMessages")]
            public Fulfillmentmessage fulfillmentMessages { get; set; }
            [JsonProperty("intent")]
            public Intent intent { get; set; }
            [JsonProperty("intentDetectionConfidence")]
            public int intentDetectionConfidence { get; set; }
            [JsonProperty("diagnosticInfo")]
            public Diagnosticinfo diagnosticInfo { get; set; }
            [JsonProperty("languageCode")]
            public string languageCode { get; set; }
            public List<KeyValuePair<string, string>> GetSlots()
            {
                var output = new List<KeyValuePair<string, string>>();
                if (Parameters == null) return output;

                foreach (var slot in Parameters.Children())
                {
                    if (slot.Name != null)
                        output.Add(new KeyValuePair<string, string>(slot.Name.ToString(), slot.Value.ToString()));
                }

                return output;
            }
        }

        [JsonObject("Intent")]
        public class Intent
        {
            [JsonProperty("name")]
            public string name { get; set; }
            [JsonProperty("displayName")]
            public string displayName { get; set; }
        }

        [JsonObject("Diagnosticinfo")]
        public class Diagnosticinfo
        {
            [JsonProperty("end_conversation")]
            public bool end_conversation { get; set; }
        }

        [JsonObject("Fulfillmentmessage")]
        public class Fulfillmentmessage
        {
            [JsonProperty("text")]
            public Text text { get; set; }
        }

        [JsonObject("Text")]
        public class Text
        {
            [JsonProperty("text")]
            public string text { get; set; }
        }

        [JsonObject("Originaldetectintentrequest")]
        public class Originaldetectintentrequest
        {
            [JsonProperty("payload")]
            public Payload payload { get; set; }
        }

        [JsonObject("Payload")]
        public class Payload
        {
        }

    }
}