﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EntitiesCore.Bots
{
    public class DilogflowRequest
    {
        //public string Session { get; set; }
        //public string ResponseId { get; set; }
        //public QueryResult queryResult { get; set; }
        //public OriginalDetectIntentRequest originalDetectIntentRequest { get; set; }

        //public class QueryResult
        //{
        //    public string QueryText { get; set; }
        //    public string LanguageCode { get; set; }
        //    public double SpeechRecognitionConfidence { get; set; }
        //    public string Action { get; set; }
        //    public Parameters Parameters { get; set; }
        //    public bool AllRequiredParamsPresent { get; set; }
        //    public string FulfillmentText { get; set; }
        //    public IList<FulfillmentMessage> FulfillmentMessages { get; set; }
        //    public string WebhookSource { get; set; }
        //    public List<string> WebhookPayload { get; set; }
        //    public List<object> OutputContexts { get; set; }
        //    public Intent Intent { get; set; }
        //    public double IntentDetectionConfidence { get; set; }
        //    public object DiagnosticInfo { get; set; }
        //}
        //public class Parameters
        //{
        //    public dynamic Fields { get; set; }
        //    public List<KeyValuePair<string, string>> GetSlots()
        //    {
        //        var output = new List<KeyValuePair<string, string>>();
        //        if (Fields == null) return output;

        //        foreach (var slot in Fields.Children())
        //        {
        //            if (slot.Value.NumberValue != 0)
        //                output.Add(new KeyValuePair<string, string>(slot.Name.ToString(), slot.Value.NumberValue.ToString()));

        //            else if (slot.Name != null)
        //                output.Add(new KeyValuePair<string, string>(slot.Name.ToString(), slot.Value.StringValue.ToString()));

        //        }

        //        return output;
        //    }
        //}
        //public class OriginalDetectIntentRequest
        //{
        //    public string Source { get; set; }
        //    public Payload Payload { get; set; }
        //}
        //public class Text
        //{
        //    public IList<string> Text_ { get; set; }
        //}
        //public class Fields
        //{
        //}
        //public class Payload
        //{
        //    public Fields fields { get; set; }
        //}
        //public class FulfillmentMessage
        //{
        //    public int MessageCase { get; set; }
        //    public Text Text { get; set; }
        //    public List<string> Image { get; set; }
        //    public List<string> QuickReplies { get; set; }
        //    public List<string> Card { get; set; }
        //    public List<string> Payload { get; set; }
        //    public List<string> SimpleResponses { get; set; }
        //    public List<string> BasicCard { get; set; }
        //    public List<string> Suggestions { get; set; }
        //    public List<string> LinkOutSuggestion { get; set; }
        //    public List<string> ListSelect { get; set; }
        //    public List<string> CarouselSelect { get; set; }
        //    public int Platform { get; set; }
        //}

        //public class IntentName
        //{
        //    public string ProjectId { get; set; }
        //    public string IntentId { get; set; }
        //    public int Kind { get; set; }
        //}

        //public class Intent
        //{
        //    public string Name { get; set; }
        //    public string DisplayName { get; set; }
        //    public int WebhookState { get; set; }
        //    public int Priority { get; set; }
        //    public bool IsFallback { get; set; }
        //    public bool MlDisabled { get; set; }
        //    public IList<string> InputContextNames { get; set; }
        //    public IList<string> Events { get; set; }
        //    public IList<string> TrainingPhrases { get; set; }
        //    public string Action { get; set; }
        //    public IList<string> OutputContexts { get; set; }
        //    public bool ResetContexts { get; set; }
        //    public IList<string> Parameters { get; set; }
        //    public IList<string> Messages { get; set; }
        //    public IList<string> DefaultResponsePlatforms { get; set; }
        //    public string RootFollowupIntentName { get; set; }
        //    public string ParentFollowupIntentName { get; set; }
        //    public IList<object> FollowupIntentInfo { get; set; }
        //    public IntentName IntentName { get; set; }
        //}

        public string responseId { get; set; }
        public QueryResult queryResult { get; set; }
        public OriginalDetectIntentRequest originalDetectIntentRequest { get; set; }
        public string session { get; set; }

        public class QueryResult
        {
            public string queryText { get; set; }
            public Parameters parameters { get; set; }
            public bool allRequiredParamsPresent { get; set; }
            public List<FulfillmentMessage> fulfillmentMessages { get; set; }
            public List<OutputContext> outputContexts { get; set; }
            public Intent intent { get; set; }
            public double intentDetectionConfidence { get; set; }
            public DiagnosticInfo diagnosticInfo { get; set; }
            public string languageCode { get; set; }
        }

        public class Parameters
        {
            public dynamic Fields { get; set; }
            public List<KeyValuePair<string, string>> GetSlots()
            {
                var output = new List<KeyValuePair<string, string>>();
                if (Fields == null) return output;

                foreach (var slot in Fields.Children())
                {
                    if (slot.Value.NumberValue != 0)
                        output.Add(new KeyValuePair<string, string>(slot.Name.ToString(), slot.Value.NumberValue.ToString()));

                    else if (slot.Name != null)
                        output.Add(new KeyValuePair<string, string>(slot.Name.ToString(), slot.Value.StringValue.ToString()));

                }

                return output;
            }
        }
        public class FulfillmentMessage
        {
            public Text text { get; set; }
        }
        public class Text
        {
            public List<string> text { get; set; }
        }

        public class OutputContext
        {
            public string name { get; set; }
            public int lifespanCount { get; set; }
            public Parameters2 parameters { get; set; }
        }

        public class Parameters2
        {
            public dynamic Fields { get; set; }
            public List<KeyValuePair<string, string>> GetSlots()
            {
                var output = new List<KeyValuePair<string, string>>();
                if (Fields == null) return output;

                foreach (var slot in Fields.Children())
                {
                    if (slot.Value.NumberValue != 0)
                        output.Add(new KeyValuePair<string, string>(slot.Name.ToString(), slot.Value.NumberValue.ToString()));

                    else if (slot.Name != null)
                        output.Add(new KeyValuePair<string, string>(slot.Name.ToString(), slot.Value.StringValue.ToString()));

                }
                return output;
            }

        }


        public class Intent
        {
            public string name { get; set; }
            public string displayName { get; set; }
        }

        public class DiagnosticInfo
        {
            public bool end_conversation { get; set; }
        }

        public class OriginalDetectIntentRequest
        {
            public Payload payload { get; set; }
        }
        public class Payload
        {
        }




    }
}
