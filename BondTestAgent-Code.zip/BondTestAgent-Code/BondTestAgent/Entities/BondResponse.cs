﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesCore.Bots
{
    public class BondResponse
    {
        private string _slotName = string.Empty;
        private string _message = string.Empty;
        private string _language = string.Empty;
        private bool _IsEndOfConversation = false;

        public string SlotName { get => _slotName; set => _slotName = value; }
        public string Message { get => _message; set => _message = value; }
        public string Language { get => _language; set => _language = value; }
        public bool IsEndOfConversation { get => _IsEndOfConversation; set => _IsEndOfConversation = value; }



    }

}
