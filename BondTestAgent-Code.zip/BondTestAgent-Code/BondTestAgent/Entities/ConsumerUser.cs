﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Business
{
    public class ConsumerUser
    {

        private int _consumerId;
        private int userId;
        private string _firstName = string.Empty;
        private string _lastName = string.Empty;
        private string _consumerNo = string.Empty;
        private int _creaditScore;
        private string _emailId = string.Empty;
        private string _contactNo = string.Empty;
        private string _accessToken = string.Empty;


        private string _passPhrase = string.Empty;       
        private string _yodleeUserId = string.Empty;
        private string _yodleePassword = string.Empty;
        private string _userSession = string.Empty;
        private string _accessTokenValue = string.Empty;
        private string _fISUserId = string.Empty;
        private string _fIS2UserId = string.Empty;


        public string UserSession
        {
            get { return _userSession; }
            set { _userSession = value; }
        }

        public string AccessTokenValue
        {
            get { return _accessTokenValue; }
            set { _accessTokenValue = value; }
        }
        
        public string FISUserId
        {
            get { return _fISUserId; }
            set { _fISUserId = value; }
        }

        public string FIS2UserId
        {
            get { return _fIS2UserId; }
            set { _fIS2UserId = value; }
        }

        public string PassPhrase
        {
            get { return _passPhrase; }
            set { _passPhrase = value; }
        }

        public string YodleeUserId
        {
            get { return _yodleeUserId; }
            set { _yodleeUserId = value; }
        }

        public string YodleePassword
        {
            get { return _yodleePassword; }
            set { _yodleePassword = value; }
        }


        public int ConsumerId
        {
            get
            {
                return _consumerId;
            }

            set
            {
                _consumerId = value;
            }
        }

        public int UserId
        {
            get
            {
                return userId;
            }

            set
            {
                userId = value;
            }
        }

        public string FirstName
        {
            get
            {
                return _firstName;
            }

            set
            {
                _firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return _lastName;
            }

            set
            {
                _lastName = value;
            }
        }

        public string ConsumerNo
        {
            get
            {
                return _consumerNo;
            }

            set
            {
                _consumerNo = value;
            }
        }

        public int CreaditScore
        {
            get
            {
                return _creaditScore;
            }

            set
            {
                _creaditScore = value;
            }
        }

        public string AccessToken
        {
            get
            {
                return _accessToken;
            }

            set
            {
                _accessToken = value;
            }
        }

        public string EmailId
        {
            get
            {
                return _emailId;
            }

            set
            {
                _emailId = value;
            }
        }

        public string ContactNo
        {
            get { return _contactNo; }
            set { _contactNo = value; }
        }
    }
}
