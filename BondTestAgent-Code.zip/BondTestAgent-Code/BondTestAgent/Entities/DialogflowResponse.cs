﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesCore.Bots
{


    public class DialogflowResponse
    {

        private string _fulfillmentText = string.Empty;
        private List<Outputcontext> _outputContexts = new List<Outputcontext>();

        public string fulfillmentText { get => _fulfillmentText; set => _fulfillmentText = value; }
        public List<Outputcontext> outputContexts { get => _outputContexts; set => _outputContexts = value; }

        //public DiagnosticInfo1 DiagnosticInfo { get; set; }

        public class Outputcontext
        {
            public string name { get; set; }
            public int lifespanCount { get; set; }
            public dynamic parameters { get; set; }
        }
        public class Parameters
        {
            public string payeeName { get; set; }
            public string confirmTransfer { get; set; }
            public string payeeAmount { get; set; }
            public string OTPCode { get; set; }
        }
    //public class Parameters
    //{
    //    public string MyProperty { get; set; }

    //    //public dynamic Fields { get; set; }
    //    //public List<KeyValuePair<string, string>> GetSlots()
    //    //{
    //    //    var output = new List<KeyValuePair<string, string>>();
    //    //    if (Fields == null) return output;

    //    //    foreach (var slot in Fields.Children())
    //    //    {
    //    //        if (slot.Value.NumberValue != 0)
    //    //            output.Add(new KeyValuePair<string, string>(slot.Name.ToString(), slot.Value.NumberValue.ToString()));

    //    //        else if (slot.Name != null)
    //    //            output.Add(new KeyValuePair<string, string>(slot.Name.ToString(), slot.Value.StringValue.ToString()));

    //    //    }

    //    //    return output;
    //    //}
    //}


}
}
