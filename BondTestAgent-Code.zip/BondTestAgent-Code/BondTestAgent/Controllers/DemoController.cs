﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
//using BAL;
//using BONDAIAPP.Utilities;
using BondAIAppV2.DialogUseCases;
//using BondAIAppV2.Intents;
using Entities.Business;
//using Entities.Data;
using EntitiesCore.Bots;
using Google.Cloud.Dialogflow.V2;
using Google.Protobuf;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using static EntitiesCore.Bots.DialogflowResponse;

namespace BondAIAppV2.Controllers
{

    [ApiController]
    public class DemoController : Controller
    {
        #region module level variable
        //static int _configLogLevel = IntelliHelpers.LoggingLevel();
        static string _pageName = MethodBase.GetCurrentMethod().DeclaringType.Name;
        string alexaResponse = string.Empty;
        #endregion
        private static readonly JsonParser jsonParser = new JsonParser(JsonParser.Settings.Default.WithIgnoreUnknownFields(true));
        string responseJson = string.Empty;
        WebhookRequest request;
        AIRequest aiRequest;
        DilogflowRequest objRequest;
        string response = string.Empty;
        BondResponse bondResponse = null;
        WebhookResponse webhookResponse = null;

        [Route("api/Demo")]
        public ContentResult DialogAction()
        {
            string strMethodName = MethodBase.GetCurrentMethod().Name;

            using (var reader = new StreamReader(Request.Body))
            {
                request = jsonParser.Parse<WebhookRequest>(reader);
            }

            //serialize the Request Class to Convert to the String
            string RequestJson = JsonConvert.SerializeObject(request);

            try
            {
                
                objRequest = JsonConvert.DeserializeObject<DilogflowRequest>(RequestJson);

                aiRequest = new AIRequest(objRequest);

                //IntelliUsersBAL intelliUsersBAL = new IntelliUsersBAL();
                string strAccessToken = aiRequest.AccessToken;

                if (strAccessToken == null || strAccessToken == "")
                    strAccessToken = "204078070218123039023046195236181101153254158019208234184019175031151028041113248108125078074215";

                //here we assign the accessToken to the alexarequestpayload object
                aiRequest.AccessToken = strAccessToken;

                DialogflowResponse dialogflowResponse = new DialogflowResponse();
                Outputcontext outputcontext = new Outputcontext();
                Parameters parameters = new Parameters();

                //ConsumerUser userObj = intelliUsersBAL.GetConsumerByAccessToken(strAccessToken);

                ConsumerUser userObj = new ConsumerUser();
                userObj.AccessToken = "204078070218123039023046195236181101153254158019208234184019175031151028041113248108125078074215";
                userObj.UserId = 1;
                userObj.FirstName = "Uday";
                userObj.EmailId = "uday@bond.ai";

                if (userObj.EmailId != "" && userObj.EmailId != null)
                {
                    switch (request.QueryResult.Intent.DisplayName.ToString().ToUpper())
                    {
                        case "XFERAMOUNT":

                            TransferUseCase transferUseCase = new TransferUseCase(userObj);
                            bondResponse = transferUseCase.HandleAlexaRequest(request);

                            webhookResponse = new WebhookResponse()
                            {
                                FulfillmentText = bondResponse.Message
                            };

                            break;

                        case "OTPINTENT":

                            TransferUseCase transferUseCase1 = new TransferUseCase(userObj);
                            bondResponse = transferUseCase1.HandleAlexaRequest(request);

                            webhookResponse = new WebhookResponse()
                            {
                                FulfillmentText = bondResponse.Message
                            };

                            for (int i = 0; i < transferUseCase1.LstRetainContexts.Count; i++)
                                webhookResponse.OutputContexts.Insert(i, transferUseCase1.LstRetainContexts[i]);

                            break;

                        default:

                            webhookResponse = new WebhookResponse()
                            {
                                FulfillmentText = "I could not locate you. Can you make sure BOND skill is enable?"
                            };
                            break;
                    }

                    responseJson = webhookResponse.ToString();
                    return Content(responseJson, "application/json");
                }
            }
            catch (Exception ex)
            {
                webhookResponse = new WebhookResponse()
                {
                    FulfillmentText = "Some problem on our side. We shall rectify it soon."
                };
                responseJson = webhookResponse.ToString();
                return Content(responseJson, "application/json");
            }

            //// Populate the response
            webhookResponse = new WebhookResponse()
            {
                FulfillmentText = bondResponse.Message.ToString()
            };
            responseJson = webhookResponse.ToString();
            return Content(responseJson, "application/json");

            // values etc.

        }
    }
}