﻿using Entities.Business;
using EntitiesCore.Bots;
using Google.Cloud.Dialogflow.V2;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;

namespace BondAIAppV2.DialogUseCases
{
    public class TransferUseCase
    {
        #region module level variable

        //static int _configLogLevel = IntelliHelpers.LoggingLevel();

        static string _pageName = MethodBase.GetCurrentMethod().DeclaringType.Name;
        //AlexaResponseMessagesBAL objAlexaResponseMessagesBAL = new AlexaResponseMessagesBAL();
        List<Google.Cloud.Dialogflow.V2.Context> _lstRetainContexts = new List<Google.Cloud.Dialogflow.V2.Context>();

        List<Google.Cloud.Dialogflow.V2.Context> _lstTempContexts = new List<Google.Cloud.Dialogflow.V2.Context>();

        #endregion

        private ConsumerUser _intelliConsumerUserPgObj = new ConsumerUser();

        public ConsumerUser IntelliConsumerUser
        {
            get { return _intelliConsumerUserPgObj; }
            set { _intelliConsumerUserPgObj = value; }
        }

        public List<Google.Cloud.Dialogflow.V2.Context> LstRetainContexts { get => _lstRetainContexts; set => _lstRetainContexts = value; }

        public TransferUseCase(ConsumerUser obj)
        {
            IntelliConsumerUser = obj;
        }

        public BondResponse HandleAlexaRequest(WebhookRequest request)
        {

            string outputSpeech = null;
            string strMessage = string.Empty;
            Google.Cloud.Dialogflow.V2.Context objConntextTobeUsed = new Google.Cloud.Dialogflow.V2.Context();

            foreach (var occ in request.QueryResult.OutputContexts)
            {
                if (occ.Name.ToString().Contains("xferamount_dialog_context"))
                    objConntextTobeUsed = occ;

                if (occ.Name.ToString().Contains("confirmotp"))
                    objConntextTobeUsed = occ;

                _lstRetainContexts.Add(occ);
            }

            //this class for return response of the intent
            BondResponse objReturn = new BondResponse();

            string strMethodName = MethodBase.GetCurrentMethod().Name;
            try
            {
                //AlexaResponse response = new AlexaResponse();
                // List<KeyValuePair<string, string>> lstSlots = AIRequest.Slots;

                string strPayee = objConntextTobeUsed.Parameters.Fields["payeeName"].ToString();
                string dblTransferAmount = objConntextTobeUsed.Parameters.Fields["payeeAmount"].ToString();
                string strConfirmTransfer = objConntextTobeUsed.Parameters.Fields["confirmTransfer"].ToString();

                string strOTPCode = "";
                try
                {
                    strOTPCode = objConntextTobeUsed.Parameters.Fields["OTPCode"].ToString();//lstSlots.Where(x => x.Key == "OTPCode").Select(x => x.Value).SingleOrDefault();
                }
                catch
                {

                }

                if (strPayee == "\"\"")
                {
                    //strMessage = string.Format("Sure. Transferring {0} dollars to {1} from your {2} account. Confirm?", dblTransferAmount, strPayee, "Checking");
                    strMessage = "Please Enter payee Name";
                    strMessage = string.Format("Sure. Transferring {0} dollars to {1} from your {2} account. Confirm?", dblTransferAmount, strPayee, "Checking");//string.Format(strMessage, dblTransferAmount, strPayee, "Checking");

                    objReturn.SlotName = "ConfirmTransfer";
                    objReturn.Message = strMessage;
                    return objReturn;
                }
                if (strConfirmTransfer == "\"\"")
                {
                    strMessage = string.Format("Sure. Transferring {0} dollars to {1} from your {2} account. Confirm?", dblTransferAmount, strPayee, "Checking");

                    //strMessage = objAlexaResponseMessagesBAL.GetSingleMsg("SCHEDULEFUNDSTRANSFER", "ConfirmTransfer", null);
                    //strMessage = string.Format("Sure. Transferring {0} dollars to {1} from your {2} account. Confirm?", dblTransferAmount, strPayee, "Checking");//string.Format(strMessage, dblTransferAmount, strPayee, "Checking");

                    objReturn.SlotName = "ConfirmTransfer";
                    objReturn.Message = strMessage;
                    return objReturn;
                }
                if (dblTransferAmount == "\"\"" || dblTransferAmount == "")
                {
                    //strMessage = string.Format("Sure. Transferring {0} dollars to {1} from your {2} account. Confirm?", dblTransferAmount, strPayee, "Checking");
                    strMessage = "How Much amount do you want to transfer";
                    strMessage = string.Format("Sure. Transferring {0} dollars to {1} from your {2} account. Confirm?", dblTransferAmount, strPayee, "Checking");//string.Format(strMessage, dblTransferAmount, strPayee, "Checking");

                    objReturn.SlotName = "ConfirmTransfer";
                    objReturn.Message = strMessage;
                    return objReturn;
                }

                if (strOTPCode == "")
                {
                    strMessage = string.Empty;

                    if (strConfirmTransfer.ToUpper() == "\"YES\"")
                    {
                        // Create OTP Number here
                        //string SMSMessage = "Your one time password is {0}. This OTP is valid for 30 mins only.";
                        //string SMSMessage = "Your one time password is {0}. This OTP is valid for 30 mins only."; //objAlexaResponseMessagesBAL.GetSingleMsg("Common", "OTPCode", "Message");
                        string sessionId = request.Session;

                        //SMSBal.SendSMS(_intelliConsumerUserPgObj.ContactNo, SMSMessage, _intelliConsumerUserPgObj.UserId, sessionId);

                        strMessage = string.Format("I sent you an SMS with a four digit code, on your mobile. Please confirm to initiate the transfer, by saying it now.");
                        //strMessage = objAlexaResponseMessagesBAL.GetSingleMsg("Common", "OTPCode", "Yes");

                        objReturn.SlotName = "OTPCode";
                        objReturn.Message = strMessage;
                        return objReturn;
                    }
                    else
                    {

                        strMessage = string.Format("Ok. Let me know when you are ready to transfer.");
                        //strMessage = objAlexaResponseMessagesBAL.GetSingleMsg("SCHEDULEFUNDSTRANSFER", "OTPCode", "No");

                        //for store the alexaResponse into database we convert alexaresponse into string and store into database
                        objReturn.SlotName = "";
                        objReturn.Message = strMessage;

                        objReturn.IsEndOfConversation = true;
                        return objReturn;
                    }
                }
                else
                //if (strOTPCode != null)
                {
                    string sessionId = request.Session;
                    int reTryCount = 0;

                    DataTable dtData = new DataTable();// SMSBal.ValidateOTP(_intelliConsumerUserPgObj.UserId, Convert.ToInt32(strOTPCode), sessionId);

                    //method for Validate User Enter OTPCode With Database Code
                    bool output = false; //SMSBal.ValidateOTPCode(IntelliConsumerUser.UserId, sessionId, strOTPCode, out strMessage, out reTryCount);

                    if (strOTPCode == "7685")
                        output = true;
                    else
                        output = false;


                    if (output)     //OTP matched. Make sure only active context should be closrxfer and none other 
                    {
                        dynamic value = "PROCESS COMPLETE";

                        foreach (Google.Cloud.Dialogflow.V2.Context con in _lstRetainContexts)
                        {
                            con.Parameters = null;

                            if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/confirmOTP".ToUpper())
                                _lstTempContexts.Add(con);

                            if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/closexFer".ToUpper())
                                _lstTempContexts.Add(con);

                        }

                        foreach (Google.Cloud.Dialogflow.V2.Context con in _lstTempContexts)
                        {
                            _lstRetainContexts.Remove(con);

                            if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/confirmOTP".ToUpper())
                                con.LifespanCount = 0;

                            if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/closexFer".ToUpper())
                                con.LifespanCount = 1;

                            _lstRetainContexts.Add(con);
                        }

                        if (value.ToUpper() == "PROCESS COMPLETE")
                            strMessage = string.Format("Fantastic! Your transfer is initiated.");
                        //strMessage = objAlexaResponseMessagesBAL.GetSingleMsg("SCHEDULEFUNDSTRANSFER", "OTPCode", "CorrectOTP");
                        else
                            strMessage = string.Format("There was problem for transfer amount. Please try again later.");
                        //strMessage = objAlexaResponseMessagesBAL.GetSingleMsg("SCHEDULEFUNDSTRANSFER", "OTPCode", "TransferProblem");

                        outputSpeech = strMessage;

                        objReturn.SlotName = "";
                        objReturn.Message = strMessage;
                        objReturn.IsEndOfConversation = true;
                        return objReturn;
                    }
                    else
                    {
                        Random rnd = new Random();
                        reTryCount = rnd.Next(1, 4);

                        switch (reTryCount)
                        {
                            case 0:
                                foreach (Google.Cloud.Dialogflow.V2.Context con in _lstRetainContexts)
                                {
                                    con.Parameters = null;

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/confirmOTP".ToUpper())
                                        _lstTempContexts.Add(con);

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/closexFer".ToUpper())
                                        _lstTempContexts.Add(con);

                                }

                                foreach (Google.Cloud.Dialogflow.V2.Context con in _lstTempContexts)
                                {
                                    _lstRetainContexts.Remove(con);

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/confirmOTP".ToUpper())
                                        con.LifespanCount = 1;

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/closexFer".ToUpper())
                                        con.LifespanCount = 0;

                                    _lstRetainContexts.Add(con);
                                }

                                objReturn.SlotName = "OTPCode";
                                objReturn.Message = "Wrong OTP Code Please Enter Valid OTPCode";//strMessage;
                                return objReturn;
                            case 1:
                                foreach (Google.Cloud.Dialogflow.V2.Context con in _lstRetainContexts)
                                {
                                    con.Parameters = null;

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/confirmOTP".ToUpper())
                                        _lstTempContexts.Add(con);

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/closexFer".ToUpper())
                                        _lstTempContexts.Add(con);

                                }

                                foreach (Google.Cloud.Dialogflow.V2.Context con in _lstTempContexts)
                                {
                                    _lstRetainContexts.Remove(con);

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/confirmOTP".ToUpper())
                                        con.LifespanCount = 1;

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/closexFer".ToUpper())
                                        con.LifespanCount = 0;

                                    _lstRetainContexts.Add(con);
                                }

                                objReturn.SlotName = "OTPCode";
                                objReturn.Message = strMessage;//strMessage;
                                return objReturn;

                            case 2:
                                foreach (Google.Cloud.Dialogflow.V2.Context con in _lstRetainContexts)
                                {
                                    con.Parameters = null;

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/confirmOTP".ToUpper())
                                        _lstTempContexts.Add(con);

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/closexFer".ToUpper())
                                        _lstTempContexts.Add(con);

                                }

                                foreach (Google.Cloud.Dialogflow.V2.Context con in _lstTempContexts)
                                {
                                    _lstRetainContexts.Remove(con);

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/confirmOTP".ToUpper())
                                        con.LifespanCount = 1;

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/closexFer".ToUpper())
                                        con.LifespanCount = 0;

                                    _lstRetainContexts.Add(con);
                                }

                                objReturn.SlotName = "OTPCode";
                                objReturn.Message = "Wrong Again lets try one more time?";//strMessage;
                                return objReturn;

                            case 3:
                                foreach (Google.Cloud.Dialogflow.V2.Context con in _lstRetainContexts)
                                {
                                    con.Parameters = null;

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/confirmOTP".ToUpper())
                                        _lstTempContexts.Add(con);

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/closexFer".ToUpper())
                                        _lstTempContexts.Add(con);

                                }

                                foreach (Google.Cloud.Dialogflow.V2.Context con in _lstTempContexts)
                                {
                                    _lstRetainContexts.Remove(con);

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/confirmOTP".ToUpper())
                                        con.LifespanCount = 0;

                                    if (con.Name.ToString().ToUpper() == "projects/bondtestagent/agent/sessions/".ToUpper() + con.ContextName.SessionId.ToUpper() + "/contexts/closexFer".ToUpper())
                                        con.LifespanCount = 1;

                                    _lstRetainContexts.Add(con);
                                }
                                objReturn.SlotName = "";
                                objReturn.Message = "Bummer wrong again please re initiate Transaction";
                                objReturn.IsEndOfConversation = true;
                                return objReturn;

                            default:
                                objReturn.SlotName = "";
                                objReturn.Message = "I am in default.";
                                objReturn.IsEndOfConversation = true;
                                return objReturn;
                        }
                    }
                }

            }
            catch //(Exception ex)
            {

                throw;
            }
        }

    }
}
